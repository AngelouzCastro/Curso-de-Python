def despedirse():
    print("Adios, me estoy despidiendo desde funcion saludar del modulo despedidas")

class Despedida():
    def __init__(self):
        print("Adios, me estoy despidiendo desde el init saludar de la clase despedidas")
