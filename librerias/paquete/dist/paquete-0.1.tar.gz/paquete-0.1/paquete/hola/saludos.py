def saludar():
    print("hola, saludo desde funcion saludar del modulo saludos")

class Saludo():
    def __init__(self):
        print("te saludo desde init de calase saludo")
