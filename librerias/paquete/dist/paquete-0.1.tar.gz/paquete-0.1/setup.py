from setuptools import setup

setup(
	name ="paquete",
	version ="0.1",
	description="paquete de ejemplo",
	author="angel mtz",
	author_email="am43591@gmail.com",
	url="no hay",
	scripts=[],
	packages=["paquete","paquete.adios","paquete.hola"]
)